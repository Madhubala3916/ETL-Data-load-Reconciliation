package com.mbd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbUploadCsvFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbUploadCsvFilesApplication.class, args);
	}

}
